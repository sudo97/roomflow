/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 1.0, "minX": 0.0, "maxY": 3308.0, "series": [{"data": [[0.0, 1.0], [0.1, 1.0], [0.2, 1.0], [0.3, 1.0], [0.4, 1.0], [0.5, 1.0], [0.6, 1.0], [0.7, 1.0], [0.8, 2.0], [0.9, 2.0], [1.0, 2.0], [1.1, 2.0], [1.2, 2.0], [1.3, 2.0], [1.4, 2.0], [1.5, 2.0], [1.6, 2.0], [1.7, 2.0], [1.8, 2.0], [1.9, 2.0], [2.0, 2.0], [2.1, 2.0], [2.2, 2.0], [2.3, 2.0], [2.4, 2.0], [2.5, 2.0], [2.6, 2.0], [2.7, 2.0], [2.8, 2.0], [2.9, 2.0], [3.0, 2.0], [3.1, 2.0], [3.2, 2.0], [3.3, 2.0], [3.4, 2.0], [3.5, 2.0], [3.6, 2.0], [3.7, 2.0], [3.8, 2.0], [3.9, 2.0], [4.0, 2.0], [4.1, 2.0], [4.2, 2.0], [4.3, 2.0], [4.4, 2.0], [4.5, 2.0], [4.6, 2.0], [4.7, 2.0], [4.8, 2.0], [4.9, 2.0], [5.0, 2.0], [5.1, 2.0], [5.2, 2.0], [5.3, 2.0], [5.4, 2.0], [5.5, 2.0], [5.6, 2.0], [5.7, 2.0], [5.8, 2.0], [5.9, 2.0], [6.0, 2.0], [6.1, 2.0], [6.2, 2.0], [6.3, 2.0], [6.4, 2.0], [6.5, 2.0], [6.6, 2.0], [6.7, 2.0], [6.8, 2.0], [6.9, 2.0], [7.0, 2.0], [7.1, 2.0], [7.2, 2.0], [7.3, 2.0], [7.4, 2.0], [7.5, 2.0], [7.6, 2.0], [7.7, 2.0], [7.8, 2.0], [7.9, 2.0], [8.0, 2.0], [8.1, 2.0], [8.2, 2.0], [8.3, 2.0], [8.4, 2.0], [8.5, 2.0], [8.6, 2.0], [8.7, 2.0], [8.8, 2.0], [8.9, 2.0], [9.0, 2.0], [9.1, 2.0], [9.2, 2.0], [9.3, 2.0], [9.4, 2.0], [9.5, 2.0], [9.6, 2.0], [9.7, 2.0], [9.8, 2.0], [9.9, 2.0], [10.0, 2.0], [10.1, 2.0], [10.2, 2.0], [10.3, 2.0], [10.4, 2.0], [10.5, 2.0], [10.6, 2.0], [10.7, 2.0], [10.8, 2.0], [10.9, 2.0], [11.0, 2.0], [11.1, 2.0], [11.2, 2.0], [11.3, 2.0], [11.4, 2.0], [11.5, 2.0], [11.6, 2.0], [11.7, 2.0], [11.8, 2.0], [11.9, 2.0], [12.0, 2.0], [12.1, 2.0], [12.2, 2.0], [12.3, 2.0], [12.4, 2.0], [12.5, 2.0], [12.6, 2.0], [12.7, 2.0], [12.8, 2.0], [12.9, 2.0], [13.0, 2.0], [13.1, 2.0], [13.2, 2.0], [13.3, 2.0], [13.4, 2.0], [13.5, 2.0], [13.6, 2.0], [13.7, 2.0], [13.8, 2.0], [13.9, 2.0], [14.0, 2.0], [14.1, 2.0], [14.2, 2.0], [14.3, 2.0], [14.4, 2.0], [14.5, 2.0], [14.6, 2.0], [14.7, 2.0], [14.8, 2.0], [14.9, 2.0], [15.0, 2.0], [15.1, 2.0], [15.2, 2.0], [15.3, 2.0], [15.4, 2.0], [15.5, 2.0], [15.6, 2.0], [15.7, 2.0], [15.8, 2.0], [15.9, 2.0], [16.0, 2.0], [16.1, 2.0], [16.2, 2.0], [16.3, 2.0], [16.4, 2.0], [16.5, 2.0], [16.6, 2.0], [16.7, 2.0], [16.8, 2.0], [16.9, 2.0], [17.0, 2.0], [17.1, 2.0], [17.2, 2.0], [17.3, 2.0], [17.4, 2.0], [17.5, 2.0], [17.6, 2.0], [17.7, 2.0], [17.8, 2.0], [17.9, 2.0], [18.0, 2.0], [18.1, 2.0], [18.2, 2.0], [18.3, 2.0], [18.4, 2.0], [18.5, 2.0], [18.6, 2.0], [18.7, 2.0], [18.8, 2.0], [18.9, 2.0], [19.0, 3.0], [19.1, 3.0], [19.2, 3.0], [19.3, 3.0], [19.4, 3.0], [19.5, 3.0], [19.6, 3.0], [19.7, 3.0], [19.8, 3.0], [19.9, 3.0], [20.0, 3.0], [20.1, 3.0], [20.2, 3.0], [20.3, 3.0], [20.4, 3.0], [20.5, 3.0], [20.6, 3.0], [20.7, 3.0], [20.8, 3.0], [20.9, 3.0], [21.0, 3.0], [21.1, 3.0], [21.2, 3.0], [21.3, 3.0], [21.4, 3.0], [21.5, 3.0], [21.6, 3.0], [21.7, 3.0], [21.8, 3.0], [21.9, 3.0], [22.0, 3.0], [22.1, 3.0], [22.2, 3.0], [22.3, 3.0], [22.4, 3.0], [22.5, 3.0], [22.6, 3.0], [22.7, 3.0], [22.8, 3.0], [22.9, 3.0], [23.0, 3.0], [23.1, 3.0], [23.2, 3.0], [23.3, 3.0], [23.4, 3.0], [23.5, 3.0], [23.6, 3.0], [23.7, 3.0], [23.8, 3.0], [23.9, 3.0], [24.0, 3.0], [24.1, 3.0], [24.2, 3.0], [24.3, 3.0], [24.4, 3.0], [24.5, 3.0], [24.6, 3.0], [24.7, 3.0], [24.8, 3.0], [24.9, 3.0], [25.0, 3.0], [25.1, 3.0], [25.2, 3.0], [25.3, 3.0], [25.4, 3.0], [25.5, 3.0], [25.6, 3.0], [25.7, 3.0], [25.8, 3.0], [25.9, 3.0], [26.0, 3.0], [26.1, 3.0], [26.2, 3.0], [26.3, 3.0], [26.4, 3.0], [26.5, 3.0], [26.6, 3.0], [26.7, 3.0], [26.8, 3.0], [26.9, 3.0], [27.0, 3.0], [27.1, 3.0], [27.2, 3.0], [27.3, 3.0], [27.4, 3.0], [27.5, 3.0], [27.6, 3.0], [27.7, 3.0], [27.8, 3.0], [27.9, 3.0], [28.0, 3.0], [28.1, 3.0], [28.2, 3.0], [28.3, 3.0], [28.4, 3.0], [28.5, 3.0], [28.6, 3.0], [28.7, 3.0], [28.8, 3.0], [28.9, 3.0], [29.0, 3.0], [29.1, 3.0], [29.2, 3.0], [29.3, 3.0], [29.4, 3.0], [29.5, 3.0], [29.6, 3.0], [29.7, 3.0], [29.8, 3.0], [29.9, 3.0], [30.0, 3.0], [30.1, 3.0], [30.2, 3.0], [30.3, 3.0], [30.4, 3.0], [30.5, 3.0], [30.6, 3.0], [30.7, 3.0], [30.8, 3.0], [30.9, 3.0], [31.0, 3.0], [31.1, 3.0], [31.2, 3.0], [31.3, 3.0], [31.4, 4.0], [31.5, 4.0], [31.6, 4.0], [31.7, 4.0], [31.8, 4.0], [31.9, 4.0], [32.0, 4.0], [32.1, 4.0], [32.2, 4.0], [32.3, 4.0], [32.4, 4.0], [32.5, 4.0], [32.6, 4.0], [32.7, 4.0], [32.8, 4.0], [32.9, 4.0], [33.0, 4.0], [33.1, 4.0], [33.2, 4.0], [33.3, 4.0], [33.4, 5.0], [33.5, 5.0], [33.6, 5.0], [33.7, 5.0], [33.8, 5.0], [33.9, 5.0], [34.0, 5.0], [34.1, 5.0], [34.2, 5.0], [34.3, 5.0], [34.4, 5.0], [34.5, 5.0], [34.6, 5.0], [34.7, 5.0], [34.8, 5.0], [34.9, 6.0], [35.0, 6.0], [35.1, 6.0], [35.2, 6.0], [35.3, 6.0], [35.4, 6.0], [35.5, 6.0], [35.6, 6.0], [35.7, 6.0], [35.8, 7.0], [35.9, 7.0], [36.0, 7.0], [36.1, 7.0], [36.2, 7.0], [36.3, 7.0], [36.4, 7.0], [36.5, 8.0], [36.6, 8.0], [36.7, 8.0], [36.8, 8.0], [36.9, 8.0], [37.0, 8.0], [37.1, 9.0], [37.2, 9.0], [37.3, 9.0], [37.4, 9.0], [37.5, 9.0], [37.6, 9.0], [37.7, 10.0], [37.8, 10.0], [37.9, 10.0], [38.0, 10.0], [38.1, 10.0], [38.2, 11.0], [38.3, 11.0], [38.4, 11.0], [38.5, 11.0], [38.6, 11.0], [38.7, 12.0], [38.8, 12.0], [38.9, 12.0], [39.0, 12.0], [39.1, 12.0], [39.2, 13.0], [39.3, 13.0], [39.4, 13.0], [39.5, 13.0], [39.6, 13.0], [39.7, 14.0], [39.8, 14.0], [39.9, 14.0], [40.0, 14.0], [40.1, 15.0], [40.2, 15.0], [40.3, 15.0], [40.4, 15.0], [40.5, 16.0], [40.6, 16.0], [40.7, 16.0], [40.8, 16.0], [40.9, 16.0], [41.0, 17.0], [41.1, 17.0], [41.2, 17.0], [41.3, 17.0], [41.4, 18.0], [41.5, 18.0], [41.6, 18.0], [41.7, 18.0], [41.8, 19.0], [41.9, 19.0], [42.0, 19.0], [42.1, 20.0], [42.2, 20.0], [42.3, 21.0], [42.4, 21.0], [42.5, 21.0], [42.6, 22.0], [42.7, 22.0], [42.8, 22.0], [42.9, 23.0], [43.0, 23.0], [43.1, 24.0], [43.2, 25.0], [43.3, 25.0], [43.4, 26.0], [43.5, 27.0], [43.6, 27.0], [43.7, 29.0], [43.8, 31.0], [43.9, 35.0], [44.0, 43.0], [44.1, 54.0], [44.2, 63.0], [44.3, 65.0], [44.4, 67.0], [44.5, 68.0], [44.6, 69.0], [44.7, 70.0], [44.8, 71.0], [44.9, 72.0], [45.0, 72.0], [45.1, 72.0], [45.2, 73.0], [45.3, 73.0], [45.4, 73.0], [45.5, 73.0], [45.6, 74.0], [45.7, 74.0], [45.8, 74.0], [45.9, 74.0], [46.0, 75.0], [46.1, 75.0], [46.2, 75.0], [46.3, 75.0], [46.4, 75.0], [46.5, 76.0], [46.6, 76.0], [46.7, 76.0], [46.8, 76.0], [46.9, 76.0], [47.0, 77.0], [47.1, 77.0], [47.2, 77.0], [47.3, 77.0], [47.4, 78.0], [47.5, 78.0], [47.6, 78.0], [47.7, 79.0], [47.8, 79.0], [47.9, 79.0], [48.0, 79.0], [48.1, 80.0], [48.2, 80.0], [48.3, 80.0], [48.4, 80.0], [48.5, 81.0], [48.6, 81.0], [48.7, 81.0], [48.8, 81.0], [48.9, 82.0], [49.0, 82.0], [49.1, 82.0], [49.2, 83.0], [49.3, 83.0], [49.4, 83.0], [49.5, 83.0], [49.6, 84.0], [49.7, 84.0], [49.8, 84.0], [49.9, 84.0], [50.0, 85.0], [50.1, 85.0], [50.2, 85.0], [50.3, 85.0], [50.4, 86.0], [50.5, 86.0], [50.6, 86.0], [50.7, 86.0], [50.8, 86.0], [50.9, 86.0], [51.0, 87.0], [51.1, 87.0], [51.2, 87.0], [51.3, 87.0], [51.4, 87.0], [51.5, 88.0], [51.6, 88.0], [51.7, 88.0], [51.8, 88.0], [51.9, 88.0], [52.0, 89.0], [52.1, 89.0], [52.2, 89.0], [52.3, 89.0], [52.4, 89.0], [52.5, 90.0], [52.6, 90.0], [52.7, 90.0], [52.8, 90.0], [52.9, 90.0], [53.0, 91.0], [53.1, 91.0], [53.2, 91.0], [53.3, 91.0], [53.4, 91.0], [53.5, 92.0], [53.6, 92.0], [53.7, 92.0], [53.8, 92.0], [53.9, 92.0], [54.0, 92.0], [54.1, 93.0], [54.2, 93.0], [54.3, 93.0], [54.4, 93.0], [54.5, 93.0], [54.6, 93.0], [54.7, 94.0], [54.8, 94.0], [54.9, 94.0], [55.0, 94.0], [55.1, 94.0], [55.2, 94.0], [55.3, 94.0], [55.4, 95.0], [55.5, 95.0], [55.6, 95.0], [55.7, 95.0], [55.8, 95.0], [55.9, 95.0], [56.0, 96.0], [56.1, 96.0], [56.2, 96.0], [56.3, 96.0], [56.4, 96.0], [56.5, 96.0], [56.6, 97.0], [56.7, 97.0], [56.8, 97.0], [56.9, 97.0], [57.0, 97.0], [57.1, 97.0], [57.2, 97.0], [57.3, 98.0], [57.4, 98.0], [57.5, 98.0], [57.6, 98.0], [57.7, 98.0], [57.8, 98.0], [57.9, 98.0], [58.0, 99.0], [58.1, 99.0], [58.2, 99.0], [58.3, 99.0], [58.4, 99.0], [58.5, 99.0], [58.6, 99.0], [58.7, 100.0], [58.8, 100.0], [58.9, 100.0], [59.0, 100.0], [59.1, 100.0], [59.2, 100.0], [59.3, 101.0], [59.4, 101.0], [59.5, 101.0], [59.6, 101.0], [59.7, 101.0], [59.8, 101.0], [59.9, 102.0], [60.0, 102.0], [60.1, 102.0], [60.2, 102.0], [60.3, 102.0], [60.4, 102.0], [60.5, 103.0], [60.6, 103.0], [60.7, 103.0], [60.8, 103.0], [60.9, 103.0], [61.0, 103.0], [61.1, 103.0], [61.2, 104.0], [61.3, 104.0], [61.4, 104.0], [61.5, 104.0], [61.6, 104.0], [61.7, 105.0], [61.8, 105.0], [61.9, 105.0], [62.0, 105.0], [62.1, 105.0], [62.2, 105.0], [62.3, 106.0], [62.4, 106.0], [62.5, 106.0], [62.6, 106.0], [62.7, 107.0], [62.8, 107.0], [62.9, 107.0], [63.0, 107.0], [63.1, 107.0], [63.2, 108.0], [63.3, 108.0], [63.4, 108.0], [63.5, 108.0], [63.6, 109.0], [63.7, 109.0], [63.8, 109.0], [63.9, 109.0], [64.0, 110.0], [64.1, 110.0], [64.2, 110.0], [64.3, 110.0], [64.4, 111.0], [64.5, 111.0], [64.6, 111.0], [64.7, 112.0], [64.8, 112.0], [64.9, 112.0], [65.0, 113.0], [65.1, 113.0], [65.2, 114.0], [65.3, 114.0], [65.4, 115.0], [65.5, 115.0], [65.6, 116.0], [65.7, 116.0], [65.8, 117.0], [65.9, 118.0], [66.0, 118.0], [66.1, 119.0], [66.2, 119.0], [66.3, 120.0], [66.4, 120.0], [66.5, 121.0], [66.6, 122.0], [66.7, 123.0], [66.8, 124.0], [66.9, 126.0], [67.0, 128.0], [67.1, 141.0], [67.2, 163.0], [67.3, 172.0], [67.4, 174.0], [67.5, 175.0], [67.6, 176.0], [67.7, 177.0], [67.8, 177.0], [67.9, 178.0], [68.0, 179.0], [68.1, 179.0], [68.2, 180.0], [68.3, 180.0], [68.4, 181.0], [68.5, 182.0], [68.6, 182.0], [68.7, 183.0], [68.8, 183.0], [68.9, 183.0], [69.0, 184.0], [69.1, 184.0], [69.2, 185.0], [69.3, 185.0], [69.4, 186.0], [69.5, 186.0], [69.6, 187.0], [69.7, 187.0], [69.8, 188.0], [69.9, 188.0], [70.0, 188.0], [70.1, 189.0], [70.2, 189.0], [70.3, 190.0], [70.4, 190.0], [70.5, 190.0], [70.6, 191.0], [70.7, 191.0], [70.8, 191.0], [70.9, 192.0], [71.0, 192.0], [71.1, 193.0], [71.2, 193.0], [71.3, 193.0], [71.4, 194.0], [71.5, 194.0], [71.6, 194.0], [71.7, 195.0], [71.8, 195.0], [71.9, 195.0], [72.0, 196.0], [72.1, 196.0], [72.2, 196.0], [72.3, 197.0], [72.4, 197.0], [72.5, 197.0], [72.6, 198.0], [72.7, 198.0], [72.8, 198.0], [72.9, 199.0], [73.0, 199.0], [73.1, 199.0], [73.2, 200.0], [73.3, 200.0], [73.4, 200.0], [73.5, 201.0], [73.6, 201.0], [73.7, 201.0], [73.8, 202.0], [73.9, 202.0], [74.0, 202.0], [74.1, 203.0], [74.2, 203.0], [74.3, 204.0], [74.4, 204.0], [74.5, 204.0], [74.6, 205.0], [74.7, 205.0], [74.8, 206.0], [74.9, 206.0], [75.0, 207.0], [75.1, 207.0], [75.2, 208.0], [75.3, 208.0], [75.4, 209.0], [75.5, 209.0], [75.6, 210.0], [75.7, 210.0], [75.8, 211.0], [75.9, 211.0], [76.0, 212.0], [76.1, 212.0], [76.2, 213.0], [76.3, 214.0], [76.4, 214.0], [76.5, 215.0], [76.6, 216.0], [76.7, 217.0], [76.8, 218.0], [76.9, 219.0], [77.0, 220.0], [77.1, 222.0], [77.2, 224.0], [77.3, 226.0], [77.4, 232.0], [77.5, 270.0], [77.6, 274.0], [77.7, 276.0], [77.8, 277.0], [77.9, 279.0], [78.0, 280.0], [78.1, 281.0], [78.2, 282.0], [78.3, 283.0], [78.4, 283.0], [78.5, 284.0], [78.6, 285.0], [78.7, 286.0], [78.8, 287.0], [78.9, 287.0], [79.0, 288.0], [79.1, 289.0], [79.2, 289.0], [79.3, 290.0], [79.4, 291.0], [79.5, 292.0], [79.6, 292.0], [79.7, 293.0], [79.8, 293.0], [79.9, 294.0], [80.0, 295.0], [80.1, 295.0], [80.2, 296.0], [80.3, 296.0], [80.4, 297.0], [80.5, 298.0], [80.6, 298.0], [80.7, 298.0], [80.8, 299.0], [80.9, 300.0], [81.0, 300.0], [81.1, 301.0], [81.2, 301.0], [81.3, 302.0], [81.4, 303.0], [81.5, 303.0], [81.6, 304.0], [81.7, 305.0], [81.8, 305.0], [81.9, 306.0], [82.0, 307.0], [82.1, 308.0], [82.2, 309.0], [82.3, 310.0], [82.4, 311.0], [82.5, 312.0], [82.6, 313.0], [82.7, 315.0], [82.8, 316.0], [82.9, 317.0], [83.0, 319.0], [83.1, 321.0], [83.2, 324.0], [83.3, 332.0], [83.4, 373.0], [83.5, 375.0], [83.6, 377.0], [83.7, 379.0], [83.8, 381.0], [83.9, 382.0], [84.0, 384.0], [84.1, 385.0], [84.2, 386.0], [84.3, 388.0], [84.4, 389.0], [84.5, 389.0], [84.6, 390.0], [84.7, 391.0], [84.8, 392.0], [84.9, 393.0], [85.0, 393.0], [85.1, 394.0], [85.2, 395.0], [85.3, 396.0], [85.4, 396.0], [85.5, 397.0], [85.6, 398.0], [85.7, 399.0], [85.8, 400.0], [85.9, 400.0], [86.0, 401.0], [86.1, 402.0], [86.2, 403.0], [86.3, 403.0], [86.4, 404.0], [86.5, 405.0], [86.6, 406.0], [86.7, 407.0], [86.8, 408.0], [86.9, 409.0], [87.0, 410.0], [87.1, 411.0], [87.2, 413.0], [87.3, 415.0], [87.4, 417.0], [87.5, 420.0], [87.6, 423.0], [87.7, 452.0], [87.8, 476.0], [87.9, 478.0], [88.0, 481.0], [88.1, 483.0], [88.2, 485.0], [88.3, 486.0], [88.4, 488.0], [88.5, 490.0], [88.6, 491.0], [88.7, 492.0], [88.8, 493.0], [88.9, 494.0], [89.0, 495.0], [89.1, 496.0], [89.2, 497.0], [89.3, 498.0], [89.4, 499.0], [89.5, 500.0], [89.6, 500.0], [89.7, 502.0], [89.8, 503.0], [89.9, 504.0], [90.0, 506.0], [90.1, 507.0], [90.2, 509.0], [90.3, 511.0], [90.4, 513.0], [90.5, 515.0], [90.6, 518.0], [90.7, 520.0], [90.8, 526.0], [90.9, 574.0], [91.0, 578.0], [91.1, 581.0], [91.2, 584.0], [91.3, 585.0], [91.4, 587.0], [91.5, 589.0], [91.6, 590.0], [91.7, 592.0], [91.8, 594.0], [91.9, 595.0], [92.0, 597.0], [92.1, 598.0], [92.2, 599.0], [92.3, 600.0], [92.4, 602.0], [92.5, 603.0], [92.6, 605.0], [92.7, 606.0], [92.8, 608.0], [92.9, 611.0], [93.0, 613.0], [93.1, 616.0], [93.2, 621.0], [93.3, 626.0], [93.4, 675.0], [93.5, 679.0], [93.6, 681.0], [93.7, 683.0], [93.8, 686.0], [93.9, 688.0], [94.0, 690.0], [94.1, 692.0], [94.2, 694.0], [94.3, 696.0], [94.4, 698.0], [94.5, 699.0], [94.6, 701.0], [94.7, 703.0], [94.8, 705.0], [94.9, 707.0], [95.0, 708.0], [95.1, 710.0], [95.2, 713.0], [95.3, 719.0], [95.4, 775.0], [95.5, 780.0], [95.6, 784.0], [95.7, 788.0], [95.8, 791.0], [95.9, 793.0], [96.0, 796.0], [96.1, 798.0], [96.2, 801.0], [96.3, 803.0], [96.4, 807.0], [96.5, 813.0], [96.6, 821.0], [96.7, 878.0], [96.8, 884.0], [96.9, 888.0], [97.0, 892.0], [97.1, 897.0], [97.2, 901.0], [97.3, 905.0], [97.4, 911.0], [97.5, 920.0], [97.6, 980.0], [97.7, 989.0], [97.8, 996.0], [97.9, 1002.0], [98.0, 1008.0], [98.1, 1015.0], [98.2, 1071.0], [98.3, 1087.0], [98.4, 1093.0], [98.5, 1099.0], [98.6, 1105.0], [98.7, 1120.0], [98.8, 1182.0], [98.9, 1195.0], [99.0, 1203.0], [99.1, 1222.0], [99.2, 1296.0], [99.3, 1314.0], [99.4, 1396.0], [99.5, 1420.0], [99.6, 1497.0], [99.7, 1598.0], [99.8, 1792.0], [99.9, 2082.0]], "isOverall": false, "label": "availability", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 0.0, "maxY": 21411.0, "series": [{"data": [[0.0, 21411.0], [600.0, 835.0], [700.0, 592.0], [800.0, 372.0], [900.0, 257.0], [1000.0, 234.0], [1100.0, 164.0], [1200.0, 104.0], [1300.0, 67.0], [1400.0, 65.0], [1500.0, 37.0], [100.0, 5303.0], [1600.0, 21.0], [1700.0, 20.0], [1800.0, 16.0], [1900.0, 8.0], [2000.0, 9.0], [2100.0, 6.0], [2200.0, 12.0], [2300.0, 2.0], [2400.0, 5.0], [2500.0, 1.0], [2600.0, 1.0], [2700.0, 3.0], [3000.0, 1.0], [3100.0, 2.0], [200.0, 2829.0], [3300.0, 1.0], [3200.0, 1.0], [300.0, 1791.0], [400.0, 1349.0], [500.0, 1006.0]], "isOverall": false, "label": "availability", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 3300.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 145.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 32733.0, "series": [{"data": [[0.0, 32733.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 3647.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 145.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 5.508500772797525, "minX": 1.7921763E12, "maxY": 89.57341053091541, "series": [{"data": [[1.79217642E12, 9.957073170731707], [1.7921763E12, 9.381405563689613], [1.79217636E12, 10.0]], "isOverall": false, "label": "base users (10)", "isController": false}, {"data": [[1.79217642E12, 89.57341053091541], [1.7921763E12, 5.508500772797525], [1.79217636E12, 56.13996456593273]], "isOverall": false, "label": "ramp users (+90)", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79217642E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 7200000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 10.516129032258066, "minX": 1.0, "maxY": 296.3267716535433, "series": [{"data": [[2.0, 204.0], [3.0, 209.0], [4.0, 13.92307692307692], [5.0, 10.516129032258066], [6.0, 20.888888888888893], [7.0, 18.92105263157895], [8.0, 26.055555555555554], [9.0, 137.0], [10.0, 18.18181818181818], [11.0, 36.91176470588236], [12.0, 31.09045226130652], [13.0, 34.649350649350616], [14.0, 35.88888888888892], [15.0, 40.703557312253], [16.0, 41.25868725868727], [17.0, 43.8840579710145], [18.0, 46.25367647058827], [19.0, 49.959839357429765], [20.0, 44.76136363636361], [21.0, 58.01438848920862], [22.0, 54.74615384615385], [23.0, 57.05813953488373], [24.0, 61.53358208955225], [25.0, 64.15810276679842], [26.0, 64.02316602316607], [27.0, 67.13265306122454], [28.0, 72.44615384615385], [29.0, 65.54104477611939], [30.0, 66.80286738351263], [31.0, 84.27777777777773], [32.0, 82.95435684647305], [33.0, 80.37152777777779], [34.0, 75.96503496503503], [35.0, 89.37132352941181], [36.0, 94.03952569169967], [37.0, 96.09225092250925], [38.0, 92.61389961389956], [39.0, 99.44718309859158], [40.0, 112.03265306122448], [41.0, 89.95719844357974], [42.0, 93.64383561643837], [43.0, 110.93684210526318], [44.0, 98.22950819672137], [45.0, 135.34875444839844], [46.0, 127.39826839826843], [47.0, 105.14236111111111], [48.0, 106.95131086142325], [49.0, 139.44483985765117], [50.0, 110.96629213483145], [51.0, 139.8934426229509], [52.0, 131.8661971830985], [53.0, 116.97647058823526], [54.0, 150.50000000000014], [55.0, 120.14117647058826], [56.0, 140.2188552188553], [57.0, 128.3754385964912], [58.0, 143.46979865771806], [59.0, 132.86641221374032], [60.0, 146.59931506849304], [61.0, 163.78629032258058], [62.0, 150.57198443579767], [63.0, 151.67957746478865], [64.0, 134.60937500000003], [65.0, 171.47177419354838], [66.0, 133.13013698630147], [67.0, 165.5077519379844], [68.0, 189.83582089552237], [69.0, 119.21033210332098], [70.0, 229.37190082644628], [71.0, 201.73109243697473], [72.0, 151.7466666666668], [73.0, 191.86250000000007], [74.0, 123.06493506493511], [75.0, 207.34931506849315], [76.0, 198.40645161290323], [77.0, 194.03409090909076], [78.0, 147.56331877729252], [79.0, 198.1556291390728], [80.0, 204.72619047619042], [81.0, 175.5838323353293], [82.0, 218.72762645914386], [83.0, 127.8368055555556], [84.0, 256.6528925619832], [85.0, 211.57328990228], [86.0, 178.10576923076934], [87.0, 230.87132352941185], [88.0, 226.59375000000003], [89.0, 296.3267716535433], [90.0, 241.04807692307685], [91.0, 179.07037037037045], [92.0, 229.54794520547946], [93.0, 145.67741935483858], [94.0, 203.53441295546554], [95.0, 255.37610619469024], [96.0, 279.2786885245901], [97.0, 223.58285714285722], [98.0, 231.44398340248966], [99.0, 222.78338278931753], [100.0, 245.97445752261996], [1.0, 204.0]], "isOverall": false, "label": "availability", "isController": false}, {"data": [[70.74967830253213, 173.35531827515337]], "isOverall": false, "label": "availability-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 7602.366666666667, "minX": 1.7921763E12, "maxY": 1306682.1, "series": [{"data": [[1.79217642E12, 546612.3], [1.7921763E12, 108098.1], [1.79217636E12, 1306682.1]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79217642E12, 38443.11666666667], [1.7921763E12, 7602.366666666667], [1.79217636E12, 91895.95]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79217642E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 7200000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 35.46199701937415, "minX": 1.7921763E12, "maxY": 246.4197858335784, "series": [{"data": [[1.79217642E12, 246.4197858335784], [1.7921763E12, 35.46199701937415], [1.79217636E12, 154.198454773354]], "isOverall": false, "label": "availability", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79217642E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 7200000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 35.421261798310944, "minX": 1.7921763E12, "maxY": 246.4135966204937, "series": [{"data": [[1.79217642E12, 246.4135966204937], [1.7921763E12, 35.421261798310944], [1.79217636E12, 154.19122179755934]], "isOverall": false, "label": "availability", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79217642E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 7200000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.001561665228290798, "minX": 1.7921763E12, "maxY": 0.05067064083457521, "series": [{"data": [[1.79217642E12, 0.0017683465959328147], [1.7921763E12, 0.05067064083457521], [1.79217636E12, 0.001561665228290798]], "isOverall": false, "label": "availability", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79217642E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 7200000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 1.0, "minX": 1.7921763E12, "maxY": 3308.0, "series": [{"data": [[1.79217642E12, 3308.0], [1.7921763E12, 281.0], [1.79217636E12, 2289.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79217642E12, 707.0], [1.7921763E12, 90.0], [1.79217636E12, 497.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79217642E12, 1526.4000000000487], [1.7921763E12, 169.7199999999998], [1.79217636E12, 1100.9900000000016]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79217642E12, 985.0], [1.7921763E12, 98.0], [1.79217636E12, 690.0]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.79217642E12, 1.0], [1.7921763E12, 1.0], [1.79217636E12, 1.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79217642E12, 93.0], [1.7921763E12, 14.0], [1.79217636E12, 93.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79217642E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 7200000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 5.5, "minX": 62.0, "maxY": 182.0, "series": [{"data": [[62.0, 5.5], [348.0, 97.0], [343.0, 75.5], [360.0, 106.0], [361.0, 94.5], [359.0, 93.0], [353.0, 72.0], [356.0, 102.5], [354.0, 107.5], [357.0, 87.0], [363.0, 103.0], [381.0, 19.0], [379.0, 15.0], [372.0, 16.5], [378.0, 86.5], [382.0, 96.0], [368.0, 87.0], [375.0, 96.0], [383.0, 20.0], [370.0, 76.0], [396.0, 11.0], [397.0, 25.0], [391.0, 80.5], [399.0, 80.0], [384.0, 80.0], [395.0, 92.0], [394.0, 103.0], [389.0, 89.0], [401.0, 93.0], [404.0, 16.0], [405.0, 72.0], [400.0, 16.0], [407.0, 86.0], [408.0, 73.5], [415.0, 92.0], [414.0, 102.0], [410.0, 93.0], [411.0, 182.0], [402.0, 109.0], [413.0, 107.0], [429.0, 98.0], [425.0, 84.0], [427.0, 74.0], [430.0, 100.5], [419.0, 88.0], [418.0, 92.0], [428.0, 108.0], [416.0, 75.0], [422.0, 79.5], [424.0, 92.0], [441.0, 98.5], [435.0, 96.0], [442.0, 97.5], [444.0, 122.5], [432.0, 98.5], [440.0, 101.5], [447.0, 75.0], [459.0, 79.0], [463.0, 101.0], [476.0, 78.0], [484.0, 91.5], [485.0, 98.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 485.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 5.0, "minX": 62.0, "maxY": 182.0, "series": [{"data": [[62.0, 5.0], [348.0, 97.0], [343.0, 75.5], [360.0, 105.5], [361.0, 94.5], [359.0, 93.0], [353.0, 72.0], [356.0, 102.5], [354.0, 107.5], [357.0, 87.0], [363.0, 103.0], [381.0, 19.0], [379.0, 15.0], [372.0, 16.5], [378.0, 86.5], [382.0, 96.0], [368.0, 87.0], [375.0, 96.0], [383.0, 20.0], [370.0, 76.0], [396.0, 11.0], [397.0, 25.0], [391.0, 80.5], [399.0, 80.0], [384.0, 80.0], [395.0, 92.0], [394.0, 103.0], [389.0, 89.0], [401.0, 93.0], [404.0, 16.0], [405.0, 72.0], [400.0, 16.0], [407.0, 86.0], [408.0, 73.5], [415.0, 92.0], [414.0, 102.0], [410.0, 93.0], [411.0, 182.0], [402.0, 109.0], [413.0, 107.0], [429.0, 98.0], [425.0, 84.0], [427.0, 74.0], [430.0, 100.5], [419.0, 88.0], [418.0, 92.0], [428.0, 108.0], [416.0, 75.0], [422.0, 79.5], [424.0, 92.0], [441.0, 98.5], [435.0, 96.0], [442.0, 97.5], [444.0, 122.5], [432.0, 98.5], [440.0, 101.5], [447.0, 75.0], [459.0, 79.0], [463.0, 101.0], [476.0, 78.0], [484.0, 91.5], [485.0, 98.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 485.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 33.85, "minX": 1.7921763E12, "maxY": 406.9166666666667, "series": [{"data": [[1.79217642E12, 167.98333333333332], [1.7921763E12, 33.85], [1.79217636E12, 406.9166666666667]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79217642E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 7200000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 33.55, "minX": 1.7921763E12, "maxY": 405.55, "series": [{"data": [[1.79217642E12, 169.65], [1.7921763E12, 33.55], [1.79217636E12, 405.55]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.79217642E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 7200000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 33.55, "minX": 1.7921763E12, "maxY": 405.55, "series": [{"data": [[1.79217642E12, 169.65], [1.7921763E12, 33.55], [1.79217636E12, 405.55]], "isOverall": false, "label": "availability-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79217642E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 7200000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 33.55, "minX": 1.7921763E12, "maxY": 405.55, "series": [{"data": [[1.79217642E12, 169.65], [1.7921763E12, 33.55], [1.79217636E12, 405.55]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.79217642E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 7200000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

